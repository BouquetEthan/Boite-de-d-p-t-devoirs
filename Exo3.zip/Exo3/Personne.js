"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Personne = void 0;
var Personne = /** @class */ (function () {
    function Personne(nom, sexe, adresses) {
        this._nom = nom;
        this._sexe = sexe;
        this._adresses = adresses;
    }
    Object.defineProperty(Personne.prototype, "nom", {
        get: function () { return this._nom; },
        set: function (nom) { this._nom = nom; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Personne.prototype, "sexe", {
        get: function () { return this._sexe; },
        set: function (sexe) { this._sexe = sexe; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Personne.prototype, "adresses", {
        get: function () { return this._adresses; },
        set: function (adresses) { this._adresses = adresses; },
        enumerable: false,
        configurable: true
    });
    return Personne;
}());
exports.Personne = Personne;

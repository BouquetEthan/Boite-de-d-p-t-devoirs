export class Adresse {
    private _rue: string;
    private _ville: string;
    private _codePostal: string;

    constructor(rue: string, ville: string, codePostal: string) {
        this._rue = rue;
        this._ville = ville;
        this._codePostal = codePostal;
    }

    get rue(): string { return this._rue; }
    set rue(rue: string) { this._rue = rue; }

    get ville(): string { return this._ville; }
    set ville(ville: string) { this._ville = ville; }

    get codePostal(): string { return this._codePostal; }
    set codePostal(cp: string) { this._codePostal = cp; }
}
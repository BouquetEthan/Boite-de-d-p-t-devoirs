"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListePersonnes = void 0;
var ListePersonnes = /** @class */ (function () {
    function ListePersonnes(personnes) {
        this._personnes = personnes;
    }
    Object.defineProperty(ListePersonnes.prototype, "personnes", {
        get: function () { return this._personnes; },
        set: function (personnes) { this._personnes = personnes; },
        enumerable: false,
        configurable: true
    });
    // 3. Cherche une personne par nom
    ListePersonnes.prototype.findByNom = function (s) {
        for (var _i = 0, _a = this._personnes; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.nom === s)
                return p;
        }
        return null;
    };
    // 4. Vérifie si une personne a une adresse avec le code postal donné
    ListePersonnes.prototype.findByCodePostal = function (cp) {
        for (var _i = 0, _a = this._personnes; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.adresses.some(function (a) { return a.codePostal === cp; }))
                return true;
        }
        return false;
    };
    // 5. Compte le nombre de personnes ayant une adresse dans la ville donnée
    ListePersonnes.prototype.countPersonneVille = function (ville) {
        var count = 0;
        for (var _i = 0, _a = this._personnes; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.adresses.some(function (a) { return a.ville === ville; }))
                count++;
        }
        return count;
    };
    // 6. Remplace le nom des personnes ayant oldNom par newNom
    ListePersonnes.prototype.editPersonneNom = function (oldNom, newNom) {
        for (var _i = 0, _a = this._personnes; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.nom === oldNom)
                p.nom = newNom;
        }
    };
    // 7. Remplace la ville des adresses des personnes ayant le nom donné
    ListePersonnes.prototype.editPersonneVille = function (nom, newVille) {
        for (var _i = 0, _a = this._personnes; _i < _a.length; _i++) {
            var p = _a[_i];
            if (p.nom === nom) {
                p.adresses.forEach(function (a) { return a.ville = newVille; });
            }
        }
    };
    return ListePersonnes;
}());
exports.ListePersonnes = ListePersonnes;

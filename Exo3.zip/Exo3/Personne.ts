import { Adresse } from "./Adresse";

export class Personne {
    private _nom: string;
    private _sexe: string;
    private _adresses: Adresse[];

    constructor(nom: string, sexe: string, adresses: Adresse[]) {
        this._nom = nom;
        this._sexe = sexe;
        this._adresses = adresses;
    }

    get nom(): string { return this._nom; }
    set nom(nom: string) { this._nom = nom; }

    get sexe(): string { return this._sexe; }
    set sexe(sexe: string) { this._sexe = sexe; }

    get adresses(): Adresse[] { return this._adresses; }
    set adresses(adresses: Adresse[]) { this._adresses = adresses; }
}
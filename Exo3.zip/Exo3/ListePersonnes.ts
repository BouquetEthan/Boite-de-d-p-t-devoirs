import { Personne } from "./Personne";
import { Adresse } from "./Adresse";

export class ListePersonnes {
    private _personnes: Personne[];

    constructor(personnes: Personne[]) {
        this._personnes = personnes;
    }

    get personnes(): Personne[] { return this._personnes; }
    set personnes(personnes: Personne[]) { this._personnes = personnes; }

    // 3. Cherche une personne par nom
    findByNom(s: string): Personne | null {
        for (const p of this._personnes) {
            if (p.nom === s) return p;
        }
        return null;
    }

    // 4. Vérifie si une personne a une adresse avec le code postal donné
    findByCodePostal(cp: string): boolean {
        for (const p of this._personnes) {
            if (p.adresses.some(a => a.codePostal === cp)) return true;
        }
        return false;
    }

    // 5. Compte le nombre de personnes ayant une adresse dans la ville donnée
    countPersonneVille(ville: string): number {
        let count = 0;
        for (const p of this._personnes) {
            if (p.adresses.some(a => a.ville === ville)) count++;
        }
        return count;
    }

    // 6. Remplace le nom des personnes ayant oldNom par newNom
    editPersonneNom(oldNom: string, newNom: string): void {
        for (const p of this._personnes) {
            if (p.nom === oldNom) p.nom = newNom;
        }
    }

    // 7. Remplace la ville des adresses des personnes ayant le nom donné
    editPersonneVille(nom: string, newVille: string): void {
        for (const p of this._personnes) {
            if (p.nom === nom) {
                p.adresses.forEach(a => a.ville = newVille);
            }
        }
    }
}
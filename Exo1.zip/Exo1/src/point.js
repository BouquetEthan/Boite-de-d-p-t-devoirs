"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Point = void 0;
var Point = /** @class */ (function () {
    function Point(_abs, _ord) {
        this._abs = _abs;
        this._ord = _ord;
    }
    Object.defineProperty(Point.prototype, "abs", {
        // Getters & Setters
        get: function () { return this._abs; },
        set: function (value) { this._abs = value; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Point.prototype, "ord", {
        get: function () { return this._ord; },
        set: function (value) { this._ord = value; },
        enumerable: false,
        configurable: true
    });
    // Methode pour camculer la distance entre deux points
    Point.prototype.CalculerDistance = function (p) {
        return Math.sqrt(Math.pow(this._abs - p.abs, 2) + Math.pow(this._ord - p.ord, 2));
    };
    Point.distance = function (x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    };
    Point.prototype.calculerMilieu = function (p) {
        var xm = ((this._abs + p.abs) / 2);
        var ym = ((this._ord + p.ord) / 2);
        return new Point(xm, ym);
    };
    Point.prototype.afficher = function () {
        return "(".concat(this._abs, ", ").concat(this._ord, ")");
    };
    return Point;
}());
exports.Point = Point;

import { TestExercice1 } from "./TestExercice1";

TestExercice1.runTests();
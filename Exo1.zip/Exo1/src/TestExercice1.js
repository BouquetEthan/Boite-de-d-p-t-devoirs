"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TestExercice1 = void 0;
var point_1 = require("./point");
var TroisPoints_1 = require("./TroisPoints");
// Exercice 1
var TestExercice1 = /** @class */ (function () {
    function TestExercice1() {
    }
    TestExercice1.runTests = function () {
        console.log("Début des tests de l'exercice 1");
        this.testerClassPoint();
        this.testerAlignement();
        this.testerIsocele();
    };
    TestExercice1.testerClassPoint = function () {
        console.log("Tests de la classe Point");
        //Test 1: créationn et getters
        var pointA = new point_1.Point(3, 4);
        var pointB = new point_1.Point(6, 8);
        console.log("Point A", pointA.afficher());
        console.log("Point B", pointB.afficher());
        //Test 2: Setters
        pointA.abs = 5;
        pointA.ord = 7;
        console.log("Point A modifié", pointA.afficher());
        //Test 3: Distance entre points
        var distanceAB = pointA.CalculerDistance(pointB);
        console.log("Distance entre A et B:", distanceAB);
        //Test 4: Methode statique
        var distanceStatique = point_1.Point.distance(5, 6, 7, 8);
        console.log("Distance statique (5,6 to 7,8):", distanceStatique);
        //Test 5: Calculer le milieu
        var milieuAB = pointA.calculerMilieu(pointB);
        console.log("Milieu A-B:", milieuAB.afficher());
    };
    TestExercice1.testerAlignement = function () {
        //Cas 1 points alignés horizontalement
        var pointsAligneHoriz = new TroisPoints_1.TroisPoints(new point_1.Point(1, 2), new point_1.Point(3, 2), new point_1.Point(5, 2));
        console.log(pointsAligneHoriz.afficher());
        console.log("Alignés (horizontal):", pointsAligneHoriz.TesterAlignement());
        //Cas 2 points alignés verticalement
        var pointsAligneVert = new TroisPoints_1.TroisPoints(new point_1.Point(2, 3), new point_1.Point(2, 6), new point_1.Point(2, 9));
        console.log(pointsAligneVert.afficher());
        console.log("Alignés (vertical):", pointsAligneVert.TesterAlignement());
        //Cas non alignés
        var pointsNonAligne = new TroisPoints_1.TroisPoints(new point_1.Point(1, 1), new point_1.Point(2, 3), new point_1.Point(4, 5));
        console.log(pointsNonAligne.afficher());
        console.log("Non alignés:", pointsNonAligne.TesterAlignement());
    };
    TestExercice1.testerIsocele = function () {
        //Cas triangle isocèle
        var isocele = new TroisPoints_1.TroisPoints(new point_1.Point(0, 0), new point_1.Point(2, 0), new point_1.Point(1, Math.sqrt(3)));
        console.log(isocele.afficher());
        console.log("Triangle isocèle:", isocele.estIsocele());
        //Cas triangle non isocèle
        var nonIsocele = new TroisPoints_1.TroisPoints(new point_1.Point(0, 0), new point_1.Point(2, 0), new point_1.Point(1, 2));
        console.log(nonIsocele.afficher());
        console.log("Triangle non isocèle:", nonIsocele.estIsocele());
    };
    return TestExercice1;
}());
exports.TestExercice1 = TestExercice1;

export class Point {
    constructor (private _abs : number, private _ord : number) {

    }
    // Getters & Setters
    get abs () : number {return this._abs;}
    set abs (value : number) {this._abs = value;}
    get ord () : number {return this._ord;}
    set ord (value : number) {this._ord = value;}

    // Methode pour camculer la distance entre deux points
    CalculerDistance (p : Point) : number {
        return Math.sqrt(Math.pow(this._abs - p.abs, 2) + Math.pow(this._ord - p.ord, 2));}
    static distance (x1 : number, y1 : number, x2 : number, y2 : number) : number {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));}

    calculerMilieu (p : Point) : Point {
    const xm = ((this._abs + p.abs) / 2);
    const ym = ((this._ord + p.ord) / 2);
    return new Point(xm, ym);
    }
    afficher () : string {
        return `(${this._abs}, ${this._ord})`;}
}

import { Point } from "./point";
import { TroisPoints } from "./TroisPoints";

// Exercice 1
export class TestExercice1 {
    static runTests() : void {
        console.log("Début des tests de l'exercice 1");
        this.testerClassPoint();
        this.testerAlignement();
        this.testerIsocele();
    }
    static testerClassPoint() : void {
        console.log("Tests de la classe Point");
        //Test 1: créationn et getters
        const pointA = new Point (3, 4);
        const pointB = new Point (6, 8);
        console.log("Point A", pointA.afficher());
        console.log("Point B", pointB.afficher());
        //Test 2: Setters
        pointA.abs = 5;
        pointA.ord = 7;
        console.log("Point A modifié", pointA.afficher());
        //Test 3: Distance entre points
        const distanceAB = pointA.CalculerDistance(pointB);
        console.log("Distance entre A et B:", distanceAB);
        //Test 4: Methode statique
        const distanceStatique = Point.distance(5, 6, 7, 8);
        console.log("Distance statique (5,6 to 7,8):", distanceStatique);
        //Test 5: Calculer le milieu
        const milieuAB = pointA.calculerMilieu(pointB);
        console.log("Milieu A-B:", milieuAB.afficher());
    }

    static testerAlignement() : void {
        //Cas 1 points alignés horizontalement
        const pointsAligneHoriz = new TroisPoints(
            new Point(1, 2),
            new Point(3, 2),
            new Point(5, 2)
        );
        console.log(pointsAligneHoriz.afficher());
        console.log("Alignés (horizontal):", pointsAligneHoriz.TesterAlignement());
        //Cas 2 points alignés verticalement
        const pointsAligneVert = new TroisPoints(
            new Point(2, 3),
            new Point(2, 6),
            new Point(2, 9)
        );
        console.log(pointsAligneVert.afficher());
        console.log("Alignés (vertical):", pointsAligneVert.TesterAlignement());
        //Cas non alignés
        const pointsNonAligne = new TroisPoints(
            new Point(1, 1),
            new Point(2, 3),
            new Point(4, 5)
        );
        console.log(pointsNonAligne.afficher());
        console.log("Non alignés:", pointsNonAligne.TesterAlignement());
    }

    static testerIsocele() : void {
        //Cas triangle isocèle
        const isocele = new TroisPoints(
            new Point(0, 0),
            new Point(2, 0),
            new Point(1, Math.sqrt(3))
        );
        console.log(isocele.afficher());
        console.log("Triangle isocèle:", isocele.estIsocele());
        //Cas triangle non isocèle
        const nonIsocele = new TroisPoints(
            new Point(0, 0),
            new Point(2, 0),
            new Point(1, 2)
        );
        console.log(nonIsocele.afficher());
        console.log("Triangle non isocèle:", nonIsocele.estIsocele());
    }
}



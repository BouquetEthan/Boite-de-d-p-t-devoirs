"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TestExercice1_1 = require("./TestExercice1");
TestExercice1_1.TestExercice1.runTests();

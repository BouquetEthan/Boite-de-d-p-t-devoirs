"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TroisPoints = void 0;
var TroisPoints = /** @class */ (function () {
    function TroisPoints(_premier, _deuxieme, _troisieme) {
        this._premier = _premier;
        this._deuxieme = _deuxieme;
        this._troisieme = _troisieme;
    }
    Object.defineProperty(TroisPoints.prototype, "premier", {
        // Getters & Setters
        get: function () { return this._premier; },
        set: function (value) { this._premier = value; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(TroisPoints.prototype, "deuxieme", {
        get: function () { return this._deuxieme; },
        set: function (value) { this._deuxieme = value; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(TroisPoints.prototype, "troisieme", {
        get: function () { return this._troisieme; },
        set: function (value) { this._troisieme = value; },
        enumerable: false,
        configurable: true
    });
    //Tester l'alignement de trois points
    TroisPoints.prototype.TesterAlignement = function () {
        var AB = this._premier.CalculerDistance(this._deuxieme);
        var AC = this._premier.CalculerDistance(this._troisieme);
        var BC = this._deuxieme.CalculerDistance(this._troisieme);
        return Math.abs(AB - (AC + BC)) < 0.001 || Math.abs(AC - (AB + BC)) < 0.001 || Math.abs(BC - (AB + AC)) < 0.001;
    };
    //Tester si le triangle est isocèle
    TroisPoints.prototype.estIsocele = function () {
        var AB = this._premier.CalculerDistance(this._deuxieme);
        var AC = this._premier.CalculerDistance(this._troisieme);
        var BC = this._deuxieme.CalculerDistance(this._troisieme);
        return Math.abs(AB - AC) < 0.001 || Math.abs(AB - BC) < 0.001 || Math.abs(AC - BC) < 0.001;
    };
    TroisPoints.prototype.afficher = function () {
        return "(".concat(this._premier.afficher(), "), (").concat(this._deuxieme.afficher(), "), (").concat(this._troisieme.afficher(), ")");
    };
    return TroisPoints;
}());
exports.TroisPoints = TroisPoints;

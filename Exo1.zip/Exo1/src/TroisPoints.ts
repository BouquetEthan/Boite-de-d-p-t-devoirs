import { Point } from "./point";

export class TroisPoints {

constructor (private _premier : Point, private _deuxieme : Point, private _troisieme : Point) {}

// Getters & Setters
get premier() : Point {return this._premier;}
set premier (value : Point) {this._premier = value;}
get deuxieme() : Point {return this._deuxieme;}
set deuxieme (value : Point) {this._deuxieme = value;}
get troisieme() : Point {return this._troisieme;}
set troisieme (value : Point) {this._troisieme = value;}

//Tester l'alignement de trois points
TesterAlignement() : boolean {
    const AB = this._premier.CalculerDistance(this._deuxieme);
    const AC = this._premier.CalculerDistance(this._troisieme);
    const BC = this._deuxieme.CalculerDistance(this._troisieme)
    return Math.abs(AB-(AC + BC)) < 0.001 || Math.abs(AC-(AB + BC)) < 0.001 || Math.abs(BC-(AB + AC)) < 0.001;
}

//Tester si le triangle est isocèle
estIsocele() : boolean {
    const AB = this._premier.CalculerDistance(this._deuxieme);
    const AC = this._premier.CalculerDistance(this._troisieme);
    const BC = this._deuxieme.CalculerDistance(this._troisieme);
    return Math.abs(AB - AC) < 0.001 || Math.abs(AB - BC) < 0.001 || Math.abs(AC - BC) < 0.001;
}

afficher() : string {
    return `(${this._premier.afficher()}), (${this._deuxieme.afficher()}), (${this._troisieme.afficher()})`;
}
}
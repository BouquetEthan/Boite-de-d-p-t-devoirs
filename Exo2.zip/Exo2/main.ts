import { Stagiaire } from "./Stagiaire";
import { Formation } from "./formation";

export class Main {
    public static main(): void {
        console.log("Démarrage du programme Exercice 2");
        // Création de stagiaires
        const formation=Main.initialiserDonnees();
    
    }
    private static initialiserDonnees(): Formation {
        // Création de trois stagiaires
        const stagiaire1 = new Stagiaire("Alice", [12, 15, 14]);
        const stagiaire2 = new Stagiaire("Bob", [10, 18, 16]);
        const stagiaire3 = new Stagiaire("Charlie", [17, 13, 19]);
        const stagiaires: Stagiaire[] = [stagiaire1, stagiaire2, stagiaire3];
        // Création d'une formation et ajout des stagiaires
        const formation = new Formation("Typescript", 90, stagiaires);
        console.log(`Moyenne de la formation ${formation.intitule} : ${formation.calculerMoyenneFormation()}`);
        console.log(`Stagiaire avec la meilleure moyenne: ${formation.afficherNomMax()}`);
        return formation;
    }
}

// Création de trois stagiaires
const stagiaire1 = new Stagiaire("Alice", [12, 15, 14]);
const stagiaire2 = new Stagiaire("Bob", [10, 18, 16]);
const stagiaire3 = new Stagiaire("Charlie", [17, 13, 19]);

// Création d'une formation et ajout des stagiaires
const formation = new Formation("Dev Web", 5, [stagiaire1, stagiaire2, stagiaire3]);

// Test des méthodes sur chaque stagiaire
formation.stagiaires.forEach((stagiaire, i) => {
    console.log(`Stagiaire ${i + 1} : ${stagiaire.nom}`);
    console.log("Notes :", stagiaire.notes);
    console.log("Moyenne :", stagiaire.calculerMoyenne());
    console.log("Note max :", stagiaire.trouverMax());
    console.log("Note min :", stagiaire.trouverMin());
    console.log("-----------------------------");
});

// Test des méthodes de Formation (supposées implémentées dans Formation.ts)
console.log("Indice du meilleur stagiaire :", formation.getIndexMax());
console.log("Nom du meilleur stagiaire :", formation.stagiaires[formation.getIndexMax()].nom);
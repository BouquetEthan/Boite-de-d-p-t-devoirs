"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Formation = void 0;
var Formation = /** @class */ (function () {
    // constructeur
    function Formation(intitulé, nbrJours, stagiaires) {
        this._intitule = intitulé;
        this._nbrJours = nbrJours;
        this._stagiaires = stagiaires;
    }
    Object.defineProperty(Formation.prototype, "intitule", {
        // getters et setters
        get: function () {
            return this._intitule;
        },
        set: function (intitule) {
            this._intitule = intitule;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Formation.prototype, "nbrJours", {
        get: function () {
            return this._nbrJours;
        },
        set: function (nbrJours) {
            this._nbrJours = nbrJours;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Formation.prototype, "stagiaires", {
        get: function () {
            return this._stagiaires;
        },
        set: function (stagiaires) {
            this._stagiaires = stagiaires;
        },
        enumerable: false,
        configurable: true
    });
    // méthode pour calculer la moyenne de la Formation
    Formation.prototype.calculerMoyenneFormation = function () {
        if (this._stagiaires.length === 0)
            return 0;
        var sommeMoyennes = this._stagiaires.reduce(function (acc, stagiaire) { return acc + stagiaire.calculerMoyenne(); }, 0);
        return sommeMoyennes / this._stagiaires.length;
    };
    // méthode qui retourne l'indice du stagiaire dans le tableau stagiaires ayant la meilleure moyenne d'une formation
    Formation.prototype.getIndexMax = function () {
        if (this._stagiaires.length === 0)
            return -1;
        var maxIndex = 0;
        var maxMoyenne = this._stagiaires[0].calculerMoyenne();
        for (var i = 1; i < this._stagiaires.length; i++) {
            var moyenne = this._stagiaires[i].calculerMoyenne();
            if (moyenne > maxMoyenne) {
                maxMoyenne = moyenne;
                maxIndex = i;
            }
        }
        return maxIndex;
    };
    // méthode qui affiche le nom du stagiaire ayant la meilleure moyenne d'une formation
    Formation.prototype.afficherNomMax = function () {
        var indexMax = this.getIndexMax();
        if (indexMax !== -1) {
            console.log("Le meilleur stagiaire est : ".concat(this._stagiaires[indexMax].nom, " avec une moyenne de ").concat(this._stagiaires[indexMax].calculerMoyenne()));
        }
        else {
            console.log("Aucun stagiaire dans la formation.");
        }
    };
    // méthode qui affiche la note minimale du premier stagiaire ayant la meilleure moyenne d’une formation
    Formation.prototype.afficherMinMax = function () {
        var indexMax = this.getIndexMax();
        if (indexMax !== -1) {
            var meilleurStagiaire = this._stagiaires[indexMax];
            var noteMin = meilleurStagiaire.trouverMin();
            console.log("La note minimale du meilleur stagiaire (".concat(meilleurStagiaire.nom, ") est : ").concat(noteMin));
            var noteMax = meilleurStagiaire.trouverMax();
            console.log("La note maximale du meilleur stagiaire (".concat(meilleurStagiaire.nom, ") est : ").concat(noteMax));
        }
        else {
            console.log("Aucun stagiaire dans la formation.");
        }
    };
    // méthode qui affiche la moyenne du premier stagiaire dont le nom est passé en paramètre
    Formation.prototype.trouverMoyenneParNom = function (nom) {
        var stagiaireTrouve;
        for (var i = 0; i < this._stagiaires.length; i++) {
            if (this._stagiaires[i].nom.toLowerCase() === nom.toLowerCase()) {
                stagiaireTrouve = this._stagiaires[i];
                break;
            }
        }
        if (stagiaireTrouve) {
            console.log("La moyenne de ".concat(nom, " est : ").concat(stagiaireTrouve.calculerMoyenne().toFixed(2)));
        }
        else {
            console.log("Stagiaire avec le nom : ".concat(nom, " non trouv\u00E9."));
        }
    };
    return Formation;
}());
exports.Formation = Formation;

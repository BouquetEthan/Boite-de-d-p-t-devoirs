// classe Stagiaire
export class Stagiaire {
    private _nom: string;
    private _notes: number[];

    // constructeur
    constructor(nom: string, notes: number[]) {
        this._nom = nom;
        this._notes = notes;
    }

    // getters et setters
    public get nom(): string {
        return this._nom;
    }
    public get notes(): number[] {
        return this._notes;
    }
    public set nom(nom: string) {
        this._nom = nom;
    }
    public set notes(notes: number[]) {
        this._notes = notes;
    }

    // méthode pour calculer la moyenne des notes
    public calculerMoyenne(): number {
        if (this._notes.length === 0) return 0;
        const somme = this._notes.reduce((acc, note) => acc + note, 0);
        return somme / this._notes.length;
    }

    // méthode pour trouver la note maximale
    public trouverMax(): number {
        if (this._notes.length === 0) return 0;
        return Math.max(...this._notes);
    }

    // méthode pour trouver la note minimale
    public trouverMin(): number {
        if (this._notes.length === 0) return 0;
        return Math.min(...this._notes);
    }
}




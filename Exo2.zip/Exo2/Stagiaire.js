"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Stagiaire = void 0;
// classe Stagiaire
var Stagiaire = /** @class */ (function () {
    // constructeur
    function Stagiaire(nom, notes) {
        this._nom = nom;
        this._notes = notes;
    }
    Object.defineProperty(Stagiaire.prototype, "nom", {
        // getters et setters
        get: function () {
            return this._nom;
        },
        set: function (nom) {
            this._nom = nom;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Stagiaire.prototype, "notes", {
        get: function () {
            return this._notes;
        },
        set: function (notes) {
            this._notes = notes;
        },
        enumerable: false,
        configurable: true
    });
    // méthode pour calculer la moyenne des notes
    Stagiaire.prototype.calculerMoyenne = function () {
        if (this._notes.length === 0)
            return 0;
        var somme = this._notes.reduce(function (acc, note) { return acc + note; }, 0);
        return somme / this._notes.length;
    };
    // méthode pour trouver la note maximale
    Stagiaire.prototype.trouverMax = function () {
        if (this._notes.length === 0)
            return 0;
        return Math.max.apply(Math, this._notes);
    };
    // méthode pour trouver la note minimale
    Stagiaire.prototype.trouverMin = function () {
        if (this._notes.length === 0)
            return 0;
        return Math.min.apply(Math, this._notes);
    };
    return Stagiaire;
}());
exports.Stagiaire = Stagiaire;

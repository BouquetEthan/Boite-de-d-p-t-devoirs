"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Main = void 0;
var Stagiaire_1 = require("./Stagiaire");
var formation_1 = require("./formation");
var Main = /** @class */ (function () {
    function Main() {
    }
    Main.main = function () {
        console.log("Démarrage du programme Exercice 2");
        // Création de stagiaires
        var formation = Main.initialiserDonnees();
    };
    Main.initialiserDonnees = function () {
        // Création de trois stagiaires
        var stagiaire1 = new Stagiaire_1.Stagiaire("Alice", [12, 15, 14]);
        var stagiaire2 = new Stagiaire_1.Stagiaire("Bob", [10, 18, 16]);
        var stagiaire3 = new Stagiaire_1.Stagiaire("Charlie", [17, 13, 19]);
        var stagiaires = [stagiaire1, stagiaire2, stagiaire3];
        // Création d'une formation et ajout des stagiaires
        var formation = new formation_1.Formation("Typescript", 90, stagiaires);
        console.log("Moyenne de la formation ".concat(formation.intitule, " : ").concat(formation.calculerMoyenneFormation()));
        console.log("Stagiaire avec la meilleure moyenne: ".concat(formation.afficherNomMax()));
        return formation;
    };
    return Main;
}());
exports.Main = Main;
// Création de trois stagiaires
var stagiaire1 = new Stagiaire_1.Stagiaire("Alice", [12, 15, 14]);
var stagiaire2 = new Stagiaire_1.Stagiaire("Bob", [10, 18, 16]);
var stagiaire3 = new Stagiaire_1.Stagiaire("Charlie", [17, 13, 19]);
// Création d'une formation et ajout des stagiaires
var formation = new formation_1.Formation("Dev Web", 5, [stagiaire1, stagiaire2, stagiaire3]);
// Test des méthodes sur chaque stagiaire
formation.stagiaires.forEach(function (stagiaire, i) {
    console.log("Stagiaire ".concat(i + 1, " : ").concat(stagiaire.nom));
    console.log("Notes :", stagiaire.notes);
    console.log("Moyenne :", stagiaire.calculerMoyenne());
    console.log("Note max :", stagiaire.trouverMax());
    console.log("Note min :", stagiaire.trouverMin());
    console.log("-----------------------------");
});
// Test des méthodes de Formation (supposées implémentées dans Formation.ts)
console.log("Indice du meilleur stagiaire :", formation.getIndexMax());
console.log("Nom du meilleur stagiaire :", formation.stagiaires[formation.getIndexMax()].nom);

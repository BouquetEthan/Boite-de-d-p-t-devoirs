import { Stagiaire } from "./Stagiaire";
export class Formation {
    private _intitule: string;
    private _nbrJours: number;
    private _stagiaires: Stagiaire[];

    // constructeur
    constructor(intitulé: string, nbrJours: number, stagiaires: Stagiaire[]) {
        this._intitule = intitulé;
        this._nbrJours = nbrJours;
        this._stagiaires = stagiaires;
    }

    // getters et setters
    public get intitule(): string {
        return this._intitule;
    }
    public get nbrJours(): number {
        return this._nbrJours;
    }
    public get stagiaires(): Stagiaire[] {
        return this._stagiaires;
    }
    public set intitule(intitule: string) {
        this._intitule = intitule;
    }
    public set nbrJours(nbrJours: number) {
        this._nbrJours = nbrJours;
    }
    public set stagiaires(stagiaires: Stagiaire[]) {
        this._stagiaires = stagiaires;
    }

    // méthode pour calculer la moyenne de la Formation
    public calculerMoyenneFormation(): number {
        if (this._stagiaires.length === 0) return 0;
        const sommeMoyennes = this._stagiaires.reduce((acc, stagiaire) => {return acc + stagiaire.calculerMoyenne();} ,0);
        return sommeMoyennes / this._stagiaires.length;
    }

    // méthode qui retourne l'indice du stagiaire dans le tableau stagiaires ayant la meilleure moyenne d'une formation
    public getIndexMax(): number {
        if (this._stagiaires.length === 0) return -1;
        let maxIndex = 0;
        let maxMoyenne = this._stagiaires[0].calculerMoyenne();
        for (let i = 1; i < this._stagiaires.length; i++) {
            const moyenne = this._stagiaires[i].calculerMoyenne();
            if (moyenne > maxMoyenne) {
                maxMoyenne = moyenne;
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    // méthode qui affiche le nom du stagiaire ayant la meilleure moyenne d'une formation
    public afficherNomMax(): void {
        const indexMax = this.getIndexMax();
        if (indexMax !== -1) {
            console.log(`Le meilleur stagiaire est : ${this._stagiaires[indexMax].nom} avec une moyenne de ${this._stagiaires[indexMax].calculerMoyenne()}`);        }
        else {
            console.log("Aucun stagiaire dans la formation.");
        }
    }

    // méthode qui affiche la note minimale du premier stagiaire ayant la meilleure moyenne d’une formation
    public afficherMinMax(): void {
        const indexMax = this.getIndexMax();
        if (indexMax !== -1) {
            const meilleurStagiaire = this._stagiaires[indexMax];
            const noteMin = meilleurStagiaire.trouverMin();
            console.log(`La note minimale du meilleur stagiaire (${meilleurStagiaire.nom}) est : ${noteMin}`);
            const noteMax = meilleurStagiaire.trouverMax();
            console.log(`La note maximale du meilleur stagiaire (${meilleurStagiaire.nom}) est : ${noteMax}`);
        }   else {
            console.log("Aucun stagiaire dans la formation.");
        }
    }

    // méthode qui affiche la moyenne du premier stagiaire dont le nom est passé en paramètre
    public trouverMoyenneParNom(nom: string): void {
        let stagiaireTrouve: Stagiaire | undefined ;
        for (let i = 0; i < this._stagiaires.length; i++) {
            if (this._stagiaires[i].nom.toLowerCase() === nom.toLowerCase()) {
                stagiaireTrouve = this._stagiaires[i];
                break;
            }
        }
        if (stagiaireTrouve) {
            console.log(`La moyenne de ${nom} est : ${stagiaireTrouve.calculerMoyenne().toFixed(2)}`);
        }else {
            console.log(`Stagiaire avec le nom : ${nom} non trouvé.`);
        }

}
}
